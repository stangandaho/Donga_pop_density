#load necessaries packages
library(raster)
library(sf)
library(ggsn)
library(tidyverse)
library(showtext)
library(ggtext)

#import and wrangle raster and shapefile data
bj_density <- raster("ben_pd_2020_1km_UNadj.tif")
donga_shp <- st_read(dsn = "./ben_adm_1m_salb_2019_shp/Shapefiles", 
                        layer = "ben_admbnda_adm2_1m_salb_20190816") |> 
  filter(ADM1_FR == "Donga")

donga_raster <- raster::mask(x = bj_density, mask = donga_shp) |> 
  raster::as.data.frame(xy = TRUE) |> 
  drop_na() |> 
  rename("value"=ben_pd_2020_1km_UNadj)

#set fonts
source("fonts.R")

#plotting
ggplot() +
  # geom_sf(data = donga_shp |> filter(ADM2_FR%in%c("Ze", "Allada", "Toffo")), 
  #         fill = "white")+

  geom_raster(data = donga_raster, aes(x = x, y = y, fill = value), 
              show.legend = TRUE, inherit.aes = TRUE, position = "identity")+
  scale_fill_gradient(low = "white", high = "#c51010",
                      breaks = c(175, 350, 525, 700, 875))+
  guides(fill = guide_colorbar(barwidth = unit(0.6, "lines"),
                               barheight = unit(7, "lines"),
                               title.position = "top", title.hjust = 0.5))+
  geom_sf(data = donga_shp, aes(), size = 1.1, color = "#24002c", fill = "NA")+
  geom_sf_label(data = donga_shp, aes(label = ADM2_FR),
                label.r = unit(0.2, units = "lines"), label.size = 0.5, fill = "NA", color = "#26051c", family = "Narkisim", size = 4)+
  scalebar(data = donga_shp, location = "bottomleft", dist = 20, dist_unit = "km", transform = TRUE, model = "International", st.dist = 0.05, st.bottom = FALSE, box.fill = c("#b3a6a1", "#e3dcdb"), box.color = NA, st.color = "#e3dcdb", family = "Adobe Devanagari", size = 16,
           anchor = c(x = 1.126, y = 8.5), st.size = 6)+
  north(data = donga_shp, location = "topleft", symbol = 4, scale = 0.15, anchor = c(x = 1.25, y = 8.95))+
  theme_void()+
  labs(fill = expression("People.km"^-2), title = "Population density Map",
       subtitle = "Department of  <span style = 'color:#b3f9ff; 
       font-size:35px'> Donga</span> in <span style = 'color:#fc9b00; 
       font-size:30px'>#</span>Benin",
       caption = "<p style='font-family:Nyala; color:#f7f5f5;font-size:16px'>Graphic: Stanislas Mahussi GANDAHO<br>@stangandaho  | Twitter - Instagram - Linkedin<br><i style='font-family:Gabriola; color:#e3dcdb;font-size:17px'>Data source: WorldPop - www.worldpop.org </i><br></p>")+
  theme(
    #background 
    #plot.margin = margin(l = 5, r = 5, unit = "lines"),
    plot.background = element_rect(fill = "#24002c", color = "NA"),
    panel.background = element_rect(fill = "#24002c", color = "NA"),
    #title
    plot.title = element_text(family = "Onyx", color = "white",
                              size = 45, hjust = 0.5, 
                              margin = margin(t = 0.7, unit = "lines")),
    plot.subtitle = element_markdown(family = "Tekton Pro Cond", color = "#d6bca3",
                                     size = 28, hjust = 0.5, 
                                     margin = margin(b = 0.8, t=0.8, unit = "lines")),
    plot.title.position = "plot",
    #legend
    legend.background = element_blank(),
    legend.title = element_text(color = "white",
                                family = "Adobe Devanagari", size = 16,
                                margin = margin(r = 0.7, unit = "lines")
    ),
    legend.position = "right", legend.direction = "vertical",
    legend.text = element_text(color = "#e3dcdb", family = "Adobe Devanagari", size = 15),
    #caption
    plot.caption = element_markdown(margin = margin(b=0.3, r = 1, unit = "lines")
    ),
    plot.caption.position = "plot"
  )


ggsave("Donga.png", dpi=300, width = 16, height = 21, units = "cm")

